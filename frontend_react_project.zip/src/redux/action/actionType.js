export const CANCEL = 'CANCLE'
export const NEXT = 'NEXT'
export const SUBMIT = 'SUBMIT'
export const UPDATE_CLAIM= 'UPDATE_CLAIM'