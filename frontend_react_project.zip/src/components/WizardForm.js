import React, { Component } from 'react'
import ClaimInfoForm1 from './ClaimInfoForm1'
import ClaimInfoForm2 from './ClaimInfoForm2'
import propTypes from 'prop-types'
import ClaimSummarCard from './ClaimSummarCard'
import Result from './Result'
import { updateClaim } from '../redux/action/action'
import { connect } from 'react-redux'


class WizardForm extends Component {
    constructor(props) {
        super(props)
        //this.nextPage = this.nextPage.bind(this)
        //this.previousPage = this.previousPage.bind(this)
        this.state = {
          page: 1,
          //flag: false,
          claim: this.props
        }
      }

      // nextPage() {
      //   console.log("next page in wizard")
      //   this.setState({ page: this.state.page + 1 })
      // }
    
      // previousPage() {
      //   console.log("prev page in wizard")
      //   this.setState({ page: this.state.page - 1 })
      // }

      // changeFlag(){
      //   console.log("change flag in wizard")
      //   this.setState({
      //     flag:true
      //   })
      // }

    render() {
        console.log('in wizardForm render')
       
        //const { onSubmit } = this.props
        //const { page, flag } = this.state
        //console.log("wizard form flag: ", flag)
        //console.log("wizard form page: ", page)
        console.log(this.state.claim)
        console.log(this.state.claim.props.claim.claims.nextPage)
        const {nextPage} = this.state.claim.props.claim.claims.nextPage
        return (
            <div>
                <div>
                    
                    {nextPage !== 1 ? <ClaimInfoForm1 {...this.props} /> : <ClaimSummarCard props={this.state.claim} />}
                    {/* {page === 2 && (
                        <ClaimInfoForm2 {...this.props}
                            // changeFlag={this.changeFlag}
                            // previousPage={this.previousPage}
                        />
                    )} */}
                    {/* {flag === true && <Result />} */}
                    {/* {0 === 0 && <ClaimSummarCard claim={this.state.claim}/>}                     */}
                </div>
            </div>
        )
    }
}

const mapDispatchToProps=(dispatch) => ({
  updateClaim: () => dispatch(updateClaim())
})
const mapStateToProps = state => {
  console.log('in form 1 state to props', state)
  return{
      claim: state.main
      
  }
}


WizardForm.propTypes = {
    onSubmit: propTypes.func.isRequired
  }

  WizardForm = connect(
    mapStateToProps,
    mapDispatchToProps
  )(WizardForm)

export default WizardForm
