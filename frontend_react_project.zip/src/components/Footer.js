import React from 'react'
import '../style/claiminfoform1.css'

function Footer(props) {
    
    return (
        <div>
            <footer>
                <h7>  </h7>
            </footer>
        </div>
    )
}

export default Footer
