import React from 'react'

function ClaimInfo() {
    return (
        <div>
            
        </div>
    )
}

export default ClaimInfo
