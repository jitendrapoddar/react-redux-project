import React from 'react'
import '../style/claiminfoform1.css'

function Result(props) {
    return (
        <div >
            <h2>Successfully saved</h2>
        </div>
    )
}

export default Result
